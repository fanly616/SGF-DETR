import warnings, os
import random

import numpy as np
import torch
warnings.filterwarnings('ignore')
from ultralytics import RTDETR



def seed_torch(seed=42):
    seed = int(seed)
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.enabled = True


if __name__ == '__main__':
    seed_torch(42)
    model = RTDETR(r'C:\Users\15492\Desktop\0915-RTDETR\ultralytics\cfg\models\rt-detr\rtdetr-r18.yaml')
    # model.load('') # loading      pretrain weights
    model.train(data=r'C:\Users\15492\Desktop\0915-RTDETR\dataset\data.yaml',
                cache=False,
                imgsz=640,
                epochs=1,
                patience=35,
                batch=8,
                workers=4,
                project='runs/train',
                name='exp',
                seed=42,  
                deterministic=True
                )



